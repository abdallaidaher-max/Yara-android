# 小书包 Little Schoolbag

A Chinese learning app for young children (ages 4–7), for Android.

- **Words (字词)**: picture words with spoken Mandarin and the 田字格 practice grid
- **Tones (声调)**: listen and pick the tone
- **Match (认字)**: match a character to its picture
- **My book (课本)**: photograph a textbook page; tap any character to hear it, see its most common use (见 → 再见), more words and simple sentences

## Get the APK

Every push to `main` builds the app on GitHub. When the **Build APK** run finishes (Actions tab, about 5 minutes), open the **Releases** page on your phone and download `LittleSchoolbag.apk`. Android will ask you to allow installing apps from your browser or Files app the first time.

To build it yourself instead, open this folder in Android Studio and choose **Build → Build APK(s)**.

## Setup on the phone

1. **Chinese voice**: the app reads words aloud with the phone's text-to-speech. If nothing is spoken, install the Chinese (Mandarin) voice: Settings → Accessibility (or System → Languages) → Text-to-speech → Speech Services by Google → Install voice data → Chinese.
2. **Claude API key** (for the My book tab only): create a key at console.anthropic.com → API keys, then paste it in the box at the bottom of the My book tab. The key is stored only on the phone. Each photo or character lookup uses a small amount of API credit, billed by Anthropic separately from a Claude subscription.

The other three tabs work without a key and without internet (except the nicer fonts, which load when online).

## Notes

- `app/debug.keystore` is the app's signing key. Keep it in the repo so new builds install over the old app without losing saved words and stars.
- The model used is set by `MODEL` in `app/src/main/assets/index.html`.
