package com.littleschoolbag.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final int REQ_FILE = 41;

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private final Object ttsLock = new Object();
    private String ttsLang = "";
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("schoolbag", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                cameraUri = null;
                Intent intent = params.isCaptureEnabled() ? cameraIntent() : null;
                if (intent == null) intent = pickIntent();
                try {
                    startActivityForResult(intent, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            synchronized (ttsLock) {
                ttsReady = useLang("zh");
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START_URL);
    }

    /** Switches the speech engine to Chinese ("zh"), Arabic ("ar") or English ("en"). Returns false if that voice is missing. */
    private boolean useLang(String lang) {
        if (lang.equals(ttsLang)) return true;
        boolean ok = false;
        if ("zh".equals(lang)) {
            ok = tts.setLanguage(Locale.SIMPLIFIED_CHINESE) >= TextToSpeech.LANG_AVAILABLE;
            if (ok) pickVoice("zh", new String[]{"CN"});
            tts.setSpeechRate(0.6f);   // slower for young learners
            tts.setPitch(1.05f);
        } else if ("ar".equals(lang)) {
            // Prefer a Lebanese voice, then other Levantine ones, then any Arabic voice.
            for (String c : new String[]{"LB", "SY", "JO", "PS", ""}) {
                Locale l = c.isEmpty() ? new Locale("ar") : new Locale("ar", c);
                if (tts.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE
                        && tts.setLanguage(l) >= TextToSpeech.LANG_AVAILABLE) {
                    ok = true;
                    break;
                }
            }
            if (ok) pickVoice("ar", new String[]{"LB", "SY", "JO", "PS"});
            tts.setSpeechRate(0.75f);
            tts.setPitch(1.0f);
        } else {
            ok = tts.setLanguage(Locale.US) >= TextToSpeech.LANG_AVAILABLE;
            if (ok) pickVoice("en", new String[]{"US", "GB"});
            tts.setSpeechRate(0.8f);
            tts.setPitch(1.0f);
        }
        ttsLang = ok ? lang : "";
        return ok;
    }

    /** Picks the best installed voice for a language, preferring the given countries in order. */
    private void pickVoice(String lang, String[] prefer) {
        try {
            android.speech.tts.Voice best = null;
            int bestScore = -1;
            for (android.speech.tts.Voice v : tts.getVoices()) {
                Locale l = v.getLocale();
                if (!lang.equals(l.getLanguage())) continue;
                String c = l.getCountry();
                if ("zh".equals(lang) && !c.isEmpty() && !"CN".equals(c)) continue;
                if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                int score = v.getQuality() + (v.isNetworkConnectionRequired() ? 0 : 50);
                for (int i = 0; i < prefer.length; i++) if (prefer[i].equals(c)) score += 1000 - i * 100;
                if (score > bestScore) { bestScore = score; best = v; }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
        }
    }

    private Intent cameraIntent() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File f = new File(dir, "page_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (i.resolveActivity(getPackageManager()) == null) {
                cameraUri = null;
                return null;
            }
            return i;
        } catch (Exception e) {
            cameraUri = null;
            return null;
        }
    }

    private Intent pickIntent() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        return Intent.createChooser(i, "Choose a photo");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) result = new Uri[]{data.getData()};
            else if (cameraUri != null) result = new Uri[]{cameraUri};
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
        cameraUri = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__onBack && window.__onBack()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        pool.shutdownNow();
        web.destroy();
        super.onDestroy();
    }

    private void deliver(String id, int code, String body) {
        final String js = "window.__claudeDone && window.__claudeDone(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(body == null ? "" : body) + ")";
        runOnUiThread(() -> {
            if (!isDestroyed()) web.evaluateJavascript(js, null);
        });
    }

    /** Functions the page can call as window.Android.* */
    private class Bridge {
        @JavascriptInterface
        public boolean canSpeak() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speak(String text) {
            speakLang(text, "zh");
        }

        /** Speaks text in "zh", "en" or "ar". Returns false when the phone has no voice for that language. */
        @JavascriptInterface
        public boolean speakLang(String text, String lang) {
            if (tts == null || text == null) return false;
            synchronized (ttsLock) {
                if (!useLang(lang == null ? "zh" : lang)) return false;
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime());
                return true;
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent("com.android.settings.TTS_SETTINGS");
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("Chinese", text == null ? "" : text));
            });
        }

        @JavascriptInterface
        public boolean hasKey() {
            return !prefs.getString("key", "").isEmpty();
        }

        @JavascriptInterface
        public void setKey(String key) {
            prefs.edit().putString("key", key == null ? "" : key.trim()).apply();
        }

        /** Sends a Messages API request; the answer comes back through window.__claudeDone(id, status, body). */
        @JavascriptInterface
        public void callClaude(final String id, final String requestJson) {
            final String key = prefs.getString("key", "");
            pool.execute(() -> {
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(API_URL).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(180000);
                    c.setDoOutput(true);
                    c.setRequestProperty("content-type", "application/json");
                    c.setRequestProperty("x-api-key", key);
                    c.setRequestProperty("anthropic-version", "2023-06-01");
                    byte[] out = requestJson.getBytes(StandardCharsets.UTF_8);
                    c.setFixedLengthStreamingMode(out.length);
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(out);
                    }
                    int code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    deliver(id, code, readAll(in));
                } catch (Exception e) {
                    deliver(id, 0, String.valueOf(e.getMessage()));
                } finally {
                    if (c != null) c.disconnect();
                }
            });
        }
    }

    private static String readAll(InputStream in) throws java.io.IOException {
        if (in == null) return "";
        try (InputStream is = in; ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        }
    }
}
